package com.xtech.bingo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.xtech.bingo.databinding.ActivityMainBinding
import com.xtech.bingo.fragments.BeginTypeFragment
import com.xtech.bingo.fragments.JoinFragment
import com.xtech.bingo.fragments.StartFragment

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportFragmentManager.beginTransaction().replace(R.id.game_setup_fragment_container,
                                                            BeginTypeFragment()).commit()

    }
}