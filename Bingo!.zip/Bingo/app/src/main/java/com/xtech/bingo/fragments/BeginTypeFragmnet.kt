package com.xtech.bingo.fragments

import androidx.fragment.app.Fragment
import com.xtech.bingo.R

class BeginTypeFragment: Fragment(R.layout.fragment_begin_type) {
}