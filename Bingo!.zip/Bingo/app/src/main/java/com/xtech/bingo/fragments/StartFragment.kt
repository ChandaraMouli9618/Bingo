package com.xtech.bingo.fragments

import androidx.fragment.app.Fragment
import com.xtech.bingo.R

class StartFragment: Fragment(R.layout.fragment_start) {

}