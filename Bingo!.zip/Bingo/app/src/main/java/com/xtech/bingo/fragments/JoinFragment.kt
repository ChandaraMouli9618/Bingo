package com.xtech.bingo.fragments

import androidx.fragment.app.Fragment
import com.xtech.bingo.R

class JoinFragment:Fragment(R.layout.fragment_join) {

}